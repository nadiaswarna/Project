import { Controller } from '@nestjs/common';

@Controller('prescription')
export class PrescriptionController {}
