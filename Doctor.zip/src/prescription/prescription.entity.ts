import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity()
export class Prescription {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  prescriptionId: number;

  @Column()
  patientId: number;

  @Column('text')
  medicinesInstructions: string;

  @Column({ type: 'date' })
  issuedDate: Date;
}
