import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { LoginModule } from './login/login.module';
import { Login } from './login/login.entity';
import { ScheduleModule } from './schedule/schedule.module';
import { RecordsModule } from './records/records.module';
import { PrescriptionModule } from './prescription/prescription.module';
import { Prescription } from './prescription/prescription.entity';
import { PatientRecord } from './records/records.entity';
import { DoctorSchedule } from './schedule/schedule.entity';


@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: 'localhost',
      port: 5432,
      username: 'postgres',
      password: '123',
      database: 'doctor',
      entities: [Login, Prescription, PatientRecord, DoctorSchedule],
      synchronize: true,
    }),
    LoginModule,
    ScheduleModule,
    RecordsModule,
    PrescriptionModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
