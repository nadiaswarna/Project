import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';
 
@Entity('login')
export class Login {
  @PrimaryGeneratedColumn()
  did: number;
 
  @Column({ unique: true })
  demail: string;
 
  @Column()
  dpassword: string;
 
  @Column()
  dnid: number;
 
  @Column({ nullable: true })
  dphoneNumber: string;
 
}