import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity()
export class PatientRecord {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  patientId: number;

  @Column('text')
  diagnosisHistory: string;

  @Column('text')
  labTestResults: string;

  @Column('text')
  familyMedicalHistory: string;
}
