import { Controller } from '@nestjs/common';

@Controller('records')
export class RecordsController {}
