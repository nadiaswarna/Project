import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity()
export class DoctorSchedule {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  doctorId: number;

  @Column()
  availabilityCalendar: string;

  @Column()
  appointmentList: string;

  @Column({ type: 'time' })
  consultation: string;

  @Column({ type: 'time' })
  slotDuration: string;
}
