import { Controller } from '@nestjs/common';

@Controller('schedule')
export class ScheduleController {}
